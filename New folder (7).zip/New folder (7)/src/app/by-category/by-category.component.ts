import { Component, OnInit } from '@angular/core';
import { Inventory } from '../models/Inventory';
import { ByCategoryService } from './by-category.service';
import { Promos } from '../models/Promos';
import { PromoService } from '../promos/promo.service';
import { ProductService } from '../products/product-service.service';
import { AppService } from '../app.service';
import { trigger, style, transition, animate, keyframes, query, stagger } from '@angular/animations';

@Component({
  selector: 'app-by-category',
  templateUrl: './by-category.component.html',
  styleUrls: ['./by-category.component.css'],
  animations: [
    trigger('ml', [
      transition('* => *',
        [
          query(':enter', style({ opacity: 0 }), { optional: true }),

          query(':enter', stagger('300ms', [

            animate('.6s ease-in', keyframes([
              style({ opacity: 0, transform: 'translateY(-75%)', offset: 0 }),
              style({ opacity: 0.5, transform: 'translateY(35px)', offset: .3 }),
              style({ opacity: 1, transform: 'translateY(0)', offset: 1 })
            ]))]), { optional: true }),

          query(':leave', stagger('300ms', [

            animate('.6s ease-in', keyframes([
              style({ opacity: 1, transform: 'translateY(0)', offset: 0 }),
              style({ opacity: 0.5, transform: 'translateY(35px)', offset: .3 }),
              style({ opacity: 0, transform: 'translateY(-75%)', offset: 1 })
            ]))]), { optional: true }),

        ])

    ])

  ]
})
export class ByCategoryComponent implements OnInit {
  inventory:Inventory[];
  selectedCategory:string;
  categories:string[]=[
      "Health Care","Books","Groceries","Electronics","Automobiles"
  ];
  promos:Promos[]=[];
  
  length:number;

  constructor(private _byCategoryService: AppService) { }
  
  ngOnInit() {
    this._byCategoryService.getAllPromos().subscribe(promos=>{
      this.promos=promos;
    })
  }
  category1(category:string){
    this.selectedCategory=category;
    this.length = this.selectedCategory.length;
  }
  promoCode:string
  edit(){
    this._byCategoryService.editByCategory(this.promoCode,this.selectedCategory).subscribe(flag=>{
      if(flag)
        alert("Promo Applied");
      else
        alert("PromoCode Not Applicable!");
    });
  }
}