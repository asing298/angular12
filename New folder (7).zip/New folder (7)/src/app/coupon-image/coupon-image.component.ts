import { Component, OnInit } from '@angular/core';
import { Coupon } from '../models/coupon';
import { AppService } from '../app.service';

@Component({
  selector: 'app-coupon-image',
  templateUrl: './coupon-image.component.html',
  styleUrls: ['./coupon-image.component.scss']
})
export class CouponImageComponent implements OnInit {

  constructor(private appService:AppService) { }

  coupon:Coupon=new Coupon();
  isEmailSent: boolean = false;

  ngOnInit() {
    this.getcoupon();
  }
emailCoupon(coupon):void{
  this.appService.sendNewCouponEmailsToAllCustomer(coupon).subscribe(success=>
    {console.log(success?"email sent":"error");
      this.isEmailSent = success;});
}
 getcoupon(){
  this.coupon=this.appService.getCoupon();
}
}
