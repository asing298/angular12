import {Address} from './Address'
import { from } from "rxjs";

export interface Merchant{
     "merchantId":number;
     "merchantName":string;
     "email":string;
     "ADDRESS":string;
     "storeName":string;
     "merchantRating":Number;
     "merchantFeedback":string;



   
  
  }