import { Address } from "./Address";
import { Product } from "./Product";

export interface Shipment{
    "shipmentId":number;
    "address":Address;
    "product":Product;
    "deliveryDate":Date;
    "dispatchDate":Date;
    "deliveryStatus":string;
    "changedDeliveryStatus":string;
}