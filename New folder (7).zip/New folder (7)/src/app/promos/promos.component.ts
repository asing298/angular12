import { Component, OnInit } from '@angular/core';
import { Promos } from '../models/Promos';
import { PromoService } from './promo.service';
import { Inventory } from '../models/Inventory';
import { AppService } from '../app.service';

@Component({
  selector: 'app-promos',
  templateUrl: './promos.component.html',
  styleUrls: ['./promos.component.css']
})
export class PromosComponent implements OnInit {
  isEmailSent :boolean = false;
  isPromoGenerated :boolean = false;

  constructor(private _promoService:AppService) { }


  promo: Promos = {
    promoId: 0,
    promoImageUrl: '',
    promoCode: '',
    discount: 0,
    endDate: null
  };

  ngOnInit() {
  }


  addPromo(): void {
    console.log(this.promo);
    this._promoService.addPromo(this.promo).subscribe(flag => {
      this.isPromoGenerated = flag ? true : false;
      if (flag) {
        //alert("added!");
        this._promoService.sendNewPromoEmailsToAllCustomer(this.promo).subscribe(
          success => {
            this.isEmailSent = success;
            if(success){
              console.log("Email sent for new Promo "+this.promo.promoCode);
            }else{
              console.log("Error in sending new Promo email.");
            }
          }
        );
      }
    });
   
  }

}
