import { Component, OnInit } from '@angular/core';
import { Feedback } from '../models/Feedback';
import { AppService } from '../app.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  feedbacks:Feedback[]=[];
  lengthOfFeedback:Number[]=[];
  constructor(private _service:AppService) { }

  ngOnInit() {
    this._service.getAllFeedbacks().subscribe(feedbacks=>{
      this.feedbacks=feedbacks;
    })
    this._service.getNumberOfFeedbacksPerMerchant().subscribe(number=>{
      this.lengthOfFeedback=number;
      console.log(this.lengthOfFeedback)
    })
  }

}
