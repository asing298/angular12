import { Injectable } from '@angular/core';
import { Merchant } from '../models/merchant';
import {HttpClient,HttpHeaders} from '@angular/common/http'
import  {Http, Response} from '@angular/http';
import { Observable, Subject, throwError} from 'rxjs';



const headers= new HttpHeaders({ 'Content-Type':'application/json'});


@Injectable({
  providedIn: 'root'
})
export class MerchantService {

  constructor(private http:Http) { }



getMerchant():Observable<Merchant[]>{

return this.http.get('../assets/merchant.json')
.map((resp: Response)=>resp.json());

}

}
