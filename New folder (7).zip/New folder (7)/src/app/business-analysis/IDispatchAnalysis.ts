export interface IDispatchAnalysis  {
    productName: string;
    merchantName: string;
    expectedDispatchDate: Date;
    actualDispatchDate: Date;
    deliveryDate: Date;
}