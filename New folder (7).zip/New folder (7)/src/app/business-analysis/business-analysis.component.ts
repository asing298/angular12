import { Component, OnInit } from '@angular/core';
import { ISalesAnalysis } from './ISalesAnalysis';
import { AppService } from '../app.service';
import { IDispatchAnalysis } from './IDispatchAnalysis';

@Component({
  selector: 'app-business-analysis',
  templateUrl: './business-analysis.component.html',
  styleUrls: ['./business-analysis.component.css']
})
export class BusinessAnalysisComponent implements OnInit {

  salesAnalysis: ISalesAnalysis[]=[];
  fromDate: Date;
  toDate: Date;
  totalRevenue: number;
  dispatchAnalysis: IDispatchAnalysis[]=[];

  constructor(private businessAnalysisService: AppService) { }

  ngOnInit(): void {
    
  }

  getSalesAnalysis()  {
    this.businessAnalysisService.getSalesAnalysis(this.fromDate, this.toDate)
            .subscribe(
                salesAnalysis => {
                    this.salesAnalysis = salesAnalysis;
                    this.totalRevenue=salesAnalysis[0].totalRevenue;
                },
            );
  }

  getDispatchAnalysis() {
    this.businessAnalysisService.getDispatchAnalysis(this.fromDate, this.toDate)
    .subscribe(
        dispatchAnalysis => {
            this.dispatchAnalysis = dispatchAnalysis;
        },
    );

  }



}
